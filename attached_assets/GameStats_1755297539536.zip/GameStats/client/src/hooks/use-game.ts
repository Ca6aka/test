import { useGame as useGameContext } from '@/contexts/game-context';

export const useGame = useGameContext;
