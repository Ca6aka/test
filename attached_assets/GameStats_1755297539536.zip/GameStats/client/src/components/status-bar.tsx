import { DollarSign, Server, TrendingUp, Moon, Sun, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTheme } from '@/components/theme-provider';
import { useGame } from '@/contexts/game-context';
import { useLanguage } from '@/contexts/language-context';
import { LanguageSwitcher } from '@/components/language-switcher';
import { formatCurrency } from '@/lib/constants';

export function StatusBar() {
  const { theme, setTheme } = useTheme();
  const { gameState, logout } = useGame();
  const { t } = useLanguage();

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  if (!gameState.user) return null;

  return (
    <header className="bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
              <Server className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">ServerSim Dashboard</h1>
          </div>
        </div>

        <div className="flex items-center space-x-6">
          {/* Balance */}
          <div className="flex items-center space-x-2 bg-green-50 dark:bg-green-900/20 px-4 py-2 rounded-lg" data-testid="balance-display">
            <DollarSign className="w-5 h-5 text-green-600 dark:text-green-400" />
            <span className="text-sm font-medium text-slate-600 dark:text-slate-400">{t('balance')}:</span>
            <span className="text-lg font-bold text-green-600 dark:text-green-400">
              {formatCurrency(gameState.user.balance)}
            </span>
          </div>

          {/* Active Servers */}
          <div className="flex items-center space-x-2 bg-blue-50 dark:bg-blue-900/20 px-4 py-2 rounded-lg" data-testid="servers-count">
            <Server className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <span className="text-sm font-medium text-slate-600 dark:text-slate-400">{t('servers')}:</span>
            <span className="text-lg font-bold text-blue-600 dark:text-blue-400">
              {gameState.servers.length}
            </span>
          </div>

          {/* Income per Minute */}
          <div className="flex items-center space-x-2 bg-amber-50 dark:bg-amber-900/20 px-4 py-2 rounded-lg" data-testid="income-display">
            <TrendingUp className="w-5 h-5 text-amber-600 dark:text-amber-400 animate-pulse" />
            <span className="text-sm font-medium text-slate-600 dark:text-slate-400">{t('incomePerMinute')}:</span>
            <span className="text-lg font-bold text-amber-600 dark:text-amber-400">
              {formatCurrency(gameState.totalIncomePerMinute)}
            </span>
          </div>

          {/* Language Switcher */}
          <LanguageSwitcher />

          {/* Theme Toggle */}
          <Button
            variant="outline"
            size="icon"
            onClick={toggleTheme}
            className="bg-slate-100 dark:bg-slate-700"
            data-testid="theme-toggle"
          >
            {theme === 'light' ? (
              <Moon className="w-5 h-5" />
            ) : (
              <Sun className="w-5 h-5" />
            )}
          </Button>

          {/* User Menu */}
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
              <span className="text-sm font-bold text-white">
                {gameState.user.nickname[0].toUpperCase()}
              </span>
            </div>
            <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
              {gameState.user.nickname}
            </span>
            <Button
              variant="ghost"
              onClick={logout}
              className="text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200"
              data-testid="logout-button"
            >
              {t('logout')}
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
