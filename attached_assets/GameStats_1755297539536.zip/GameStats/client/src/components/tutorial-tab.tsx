import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, Heart, Monitor, Clock } from 'lucide-react';
import { useGame } from '@/contexts/game-context';
import { useLanguage } from '@/contexts/language-context';
import { useToast } from '@/hooks/use-toast';
import { JOBS, formatCurrency, formatTime } from '@/lib/constants';

export function TutorialTab() {
  const { gameState, completeJob } = useGame();
  const { t } = useLanguage();
  const { toast } = useToast();
  const [cooldownTimers, setCooldownTimers] = useState<Record<string, number>>({});

  // Update countdown timers
  useEffect(() => {
    const interval = setInterval(() => {
      setCooldownTimers(current => {
        const updated = { ...current };
        let hasChanges = false;

        Object.keys(updated).forEach(jobType => {
          if (updated[jobType] > 0) {
            updated[jobType]--;
            hasChanges = true;
          }
        });

        return hasChanges ? updated : current;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // Sync with game state cooldowns
  useEffect(() => {
    setCooldownTimers(gameState.jobCooldowns);
  }, [gameState.jobCooldowns]);

  const handleJobCompletion = async (jobType: string) => {
    try {
      await completeJob(jobType);
      const job = JOBS.find(j => j.id === jobType);
      if (job) {
        toast({
          title: "Job Completed!",
          description: `You earned ${formatCurrency(job.reward)} from "${job.name}"`,
        });
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const getJobIcon = (iconName: string) => {
    switch (iconName) {
      case 'shield-check': return Shield;
      case 'heart': return Heart;
      case 'monitor': return Monitor;
      default: return Clock;
    }
  };

  const getJobColor = (jobId: string) => {
    switch (jobId) {
      case 'vpn': return {
        bg: 'bg-green-100 dark:bg-green-900/30',
        text: 'text-green-600 dark:text-green-400',
        button: 'bg-green-500 hover:bg-green-600'
      };
      case 'dog_walk': return {
        bg: 'bg-blue-100 dark:bg-blue-900/30',
        text: 'text-blue-600 dark:text-blue-400',
        button: 'bg-blue-500 hover:bg-blue-600'
      };
      case 'computer_setup': return {
        bg: 'bg-purple-100 dark:bg-purple-900/30',
        text: 'text-purple-600 dark:text-purple-400',
        button: 'bg-purple-500 hover:bg-purple-600'
      };
      default: return {
        bg: 'bg-slate-100 dark:bg-slate-900/30',
        text: 'text-slate-600 dark:text-slate-400',
        button: 'bg-slate-500 hover:bg-slate-600'
      };
    }
  };

  const getJobTranslation = (jobId: string) => {
    switch (jobId) {
      case 'vpn': return {
        name: t('vpnSetup'),
        description: t('vpnDescription')
      };
      case 'dog_walk': return {
        name: t('dogWalking'),
        description: t('dogWalkingDescription')
      };
      case 'computer_setup': return {
        name: t('computerSetup'),
        description: t('computerSetupDescription')
      };
      default: return {
        name: jobId,
        description: ''
      };
    }
  };

  if (!gameState.user) return null;

  return (
    <div className="p-6">
      <div className="max-w-4xl">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">
            {t('tutorialTitle')}
          </h2>
          <p className="text-slate-600 dark:text-slate-400">
            {t('tutorialDescription')}
          </p>
        </div>

        {/* Simple Jobs Section */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {JOBS.map((job) => {
            const IconComponent = getJobIcon(job.icon);
            const colors = getJobColor(job.id);
            const translation = getJobTranslation(job.id);
            const cooldownRemaining = cooldownTimers[job.id] || 0;
            const progress = cooldownRemaining > 0 ? ((job.cooldownSeconds - cooldownRemaining) / job.cooldownSeconds) * 100 : 100;

            return (
              <Card key={job.id} className="hover:shadow-lg transition-shadow" data-testid={`job-card-${job.id}`}>
                <CardHeader>
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 ${colors.bg} rounded-lg flex items-center justify-center`}>
                      <IconComponent className={`w-6 h-6 ${colors.text}`} />
                    </div>
                    <span className={`text-lg font-bold ${colors.text}`}>
                      +{formatCurrency(job.reward)}
                    </span>
                  </div>
                  <CardTitle className="text-base">{translation.name}</CardTitle>
                </CardHeader>

                <CardContent>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                    {translation.description}
                  </p>

                  <div className="mb-4">
                    <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400 mb-1">
                      <span>{t('cooldown')}: {formatTime(job.cooldownSeconds)}</span>
                      <span className="font-mono">
                        {cooldownRemaining > 0 ? formatTime(cooldownRemaining) : t('ready')}
                      </span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>

                  <Button
                    className={`w-full ${cooldownRemaining > 0 
                      ? 'bg-slate-400 cursor-not-allowed' 
                      : colors.button
                    } text-white font-semibold`}
                    onClick={() => handleJobCompletion(job.id)}
                    disabled={cooldownRemaining > 0}
                    data-testid={`job-button-${job.id}`}
                  >
                    {cooldownRemaining > 0 ? t('onCooldown') : t('startJob')}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Recent Activities */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Clock className="w-5 h-5 mr-2" />
              {t('recentActivities')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3" data-testid="activities-list">
              {gameState.activities.length === 0 ? (
                <p className="text-slate-500 dark:text-slate-400 text-center py-4">
                  {t('noActivitiesYet')}
                </p>
              ) : (
                gameState.activities.slice(0, 5).map((activity) => (
                  <div
                    key={activity.id}
                    className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-700 last:border-b-0"
                    data-testid={`activity-${activity.id}`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-2 h-2 rounded-full ${
                        activity.amount > 0 ? 'bg-green-500' : 'bg-red-500'
                      }`} />
                      <span className="text-sm text-slate-600 dark:text-slate-400">
                        {activity.description}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className={`text-sm font-semibold ${
                        activity.amount > 0 
                          ? 'text-green-600 dark:text-green-400' 
                          : 'text-red-600 dark:text-red-400'
                      }`}>
                        {activity.amount > 0 ? '+' : ''}{formatCurrency(activity.amount)}
                      </span>
                      <br />
                      <span className="text-xs text-slate-400">
                        {new Date(activity.createdAt).toLocaleString()}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
