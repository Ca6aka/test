import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Server, Filter } from 'lucide-react';
import { useGame } from '@/contexts/game-context';
import { useToast } from '@/hooks/use-toast';
import { SERVER_PRODUCTS, formatCurrency } from '@/lib/constants';

export function HostingTab() {
  const { gameState, purchaseServer } = useGame();
  const { toast } = useToast();
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [priceFilter, setPriceFilter] = useState<string>('all');
  const [specializationFilter, setSpecializationFilter] = useState<string>('all');

  const handlePurchase = async (productId: string) => {
    try {
      await purchaseServer(productId);
      const product = SERVER_PRODUCTS.find(p => p.id === productId);
      toast({
        title: "Server Purchased!",
        description: `Successfully purchased ${product?.name}`,
      });
    } catch (error: any) {
      toast({
        title: "Purchase Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  // Filter products based on current filters
  const filteredProducts = SERVER_PRODUCTS.filter(product => {
    if (categoryFilter !== 'all' && product.category !== categoryFilter) return false;
    if (priceFilter !== 'all') {
      const price = product.price;
      switch (priceFilter) {
        case 'low': return price <= 200;
        case 'medium': return price > 200 && price <= 500;
        case 'high': return price > 500;
      }
    }
    if (specializationFilter !== 'all' && product.bestFor.toLowerCase() !== specializationFilter.toLowerCase()) return false;
    return true;
  });

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'entry': return 'from-blue-500 to-indigo-600';
      case 'professional': return 'from-green-500 to-emerald-600';
      case 'enterprise': return 'from-purple-500 to-pink-600';
      default: return 'from-slate-500 to-slate-600';
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case 'entry': return 'Entry Level';
      case 'professional': return 'Professional';
      case 'enterprise': return 'Enterprise';
      default: return category;
    }
  };

  if (!gameState.user) return null;

  return (
    <div className="p-6">
      <div className="max-w-6xl">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">
            Server Store
          </h2>
          <p className="text-slate-600 dark:text-slate-400">
            Choose the perfect servers for your infrastructure needs
          </p>
        </div>

        {/* Filter Section */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center text-base">
              <Filter className="w-4 h-4 mr-2" />
              Filters
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Category
                </label>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger data-testid="category-filter">
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="entry">Entry Level</SelectItem>
                    <SelectItem value="professional">Professional</SelectItem>
                    <SelectItem value="enterprise">Enterprise</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Price Range
                </label>
                <Select value={priceFilter} onValueChange={setPriceFilter}>
                  <SelectTrigger data-testid="price-filter">
                    <SelectValue placeholder="All Prices" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Prices</SelectItem>
                    <SelectItem value="low">$50 - $200</SelectItem>
                    <SelectItem value="medium">$200 - $500</SelectItem>
                    <SelectItem value="high">$500+</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Specialization
                </label>
                <Select value={specializationFilter} onValueChange={setSpecializationFilter}>
                  <SelectTrigger data-testid="specialization-filter">
                    <SelectValue placeholder="All Types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="mail service">Mail Service</SelectItem>
                    <SelectItem value="web hosting">Web Hosting</SelectItem>
                    <SelectItem value="data storage">Data Storage</SelectItem>
                    <SelectItem value="ai processing">AI Processing</SelectItem>
                    <SelectItem value="game hosting">Game Hosting</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-end">
                <Button
                  onClick={() => {
                    setCategoryFilter('all');
                    setPriceFilter('all');
                    setSpecializationFilter('all');
                  }}
                  variant="outline"
                  className="w-full"
                  data-testid="clear-filters-button"
                >
                  Clear Filters
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Server Products Grid */}
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredProducts.map((product) => {
            const canAfford = gameState.user!.balance >= product.price * 100; // Convert to cents
            
            return (
              <Card
                key={product.id}
                className="overflow-hidden hover:shadow-lg transition-shadow"
                data-testid={`product-card-${product.id}`}
              >
                <div className={`bg-gradient-to-r ${getCategoryColor(product.category)} p-4`}>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-white font-bold">
                      {product.name}
                    </CardTitle>
                    <Badge className="bg-white/20 text-white border-0">
                      {getCategoryLabel(product.category)}
                    </Badge>
                  </div>
                </div>

                <CardContent className="p-6">
                  <div className="space-y-3 mb-6">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600 dark:text-slate-400">CPU:</span>
                      <span className="font-medium text-slate-900 dark:text-white">
                        {product.specs.cpu}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600 dark:text-slate-400">RAM:</span>
                      <span className="font-medium text-slate-900 dark:text-white">
                        {product.specs.ram}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600 dark:text-slate-400">Storage:</span>
                      <span className="font-medium text-slate-900 dark:text-white">
                        {product.specs.storage}
                      </span>
                    </div>
                    {product.specs.gpu && (
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-600 dark:text-slate-400">GPU:</span>
                        <span className="font-medium text-slate-900 dark:text-white">
                          {product.specs.gpu}
                        </span>
                      </div>
                    )}
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600 dark:text-slate-400">Best For:</span>
                      <span className={`font-medium ${getCategoryColor(product.category).includes('blue') 
                        ? 'text-blue-600 dark:text-blue-400' 
                        : getCategoryColor(product.category).includes('green')
                        ? 'text-green-600 dark:text-green-400'
                        : 'text-purple-600 dark:text-purple-400'
                      }`}>
                        {product.bestFor}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm border-t border-slate-200 dark:border-slate-700 pt-3">
                      <span className="text-slate-600 dark:text-slate-400">Income Potential:</span>
                      <span className="font-bold text-green-600 dark:text-green-400">
                        {formatCurrency(product.incomePerMinute)}/min
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between mb-4">
                    <span className="text-2xl font-bold text-slate-900 dark:text-white">
                      {formatCurrency(product.price * 100)}
                    </span>
                    <span className="text-sm text-slate-600 dark:text-slate-400">
                      One-time purchase
                    </span>
                  </div>

                  <Button
                    className={`w-full font-semibold py-3 ${
                      canAfford
                        ? 'bg-blue-500 hover:bg-blue-600 text-white'
                        : 'bg-slate-400 cursor-not-allowed text-white'
                    }`}
                    onClick={() => handlePurchase(product.id)}
                    disabled={!canAfford}
                    data-testid={`purchase-button-${product.id}`}
                  >
                    {canAfford ? (
                      <>
                        <Server className="w-4 h-4 mr-1" />
                        Purchase Server
                      </>
                    ) : (
                      'Insufficient Funds'
                    )}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-8">
            <p className="text-slate-500 dark:text-slate-400">
              No servers match your current filters. Try adjusting your search criteria.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
