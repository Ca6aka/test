import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { CheckCircle, Clock, Lock, BookOpen } from 'lucide-react';
import { useGame } from '@/contexts/game-context';
import { SPECIALIZATIONS } from '@/lib/constants';

export function LearningTab() {
  const { gameState } = useGame();

  const getSpecializationStatus = (spec: any) => {
    if (spec.learningProgress === 100) return 'completed';
    if (spec.learningProgress > 0) return 'in-progress';
    if (spec.prerequisite) {
      const prerequisite = SPECIALIZATIONS.find(s => s.id === spec.prerequisite);
      if (!prerequisite || prerequisite.learningProgress !== 100) return 'locked';
    }
    return 'available';
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return CheckCircle;
      case 'in-progress': return Clock;
      case 'locked': return Lock;
      default: return BookOpen;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600 dark:text-green-400';
      case 'in-progress': return 'text-blue-600 dark:text-blue-400';
      case 'locked': return 'text-slate-400';
      default: return 'text-slate-600 dark:text-slate-400';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed': return <Badge className="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300">Completed</Badge>;
      case 'in-progress': return <Badge className="bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300">In Progress</Badge>;
      case 'locked': return <Badge variant="secondary">Locked</Badge>;
      default: return <Badge variant="outline">Available</Badge>;
    }
  };

  if (!gameState.user) return null;

  const completedCount = SPECIALIZATIONS.filter(s => s.learningProgress === 100).length;
  const inProgressCount = SPECIALIZATIONS.filter(s => s.learningProgress > 0 && s.learningProgress < 100).length;
  const lockedCount = SPECIALIZATIONS.length - completedCount - inProgressCount;

  return (
    <div className="p-6">
      <div className="max-w-4xl">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">
            Learning Center
          </h2>
          <p className="text-slate-600 dark:text-slate-400">
            Master server specializations to unlock new income opportunities
          </p>
        </div>

        {/* Learning Progress Overview */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center text-base">
              <BookOpen className="w-4 h-4 mr-2" />
              Learning Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center" data-testid="completed-progress">
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-2">
                  <span className="text-lg font-bold text-green-600 dark:text-green-400">
                    {completedCount}
                  </span>
                </div>
                <p className="text-sm font-medium text-slate-900 dark:text-white">Completed</p>
                <p className="text-xs text-slate-600 dark:text-slate-400">Specializations</p>
              </div>
              
              <div className="text-center" data-testid="inprogress-progress">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center mx-auto mb-2">
                  <span className="text-lg font-bold text-blue-600 dark:text-blue-400">
                    {inProgressCount}
                  </span>
                </div>
                <p className="text-sm font-medium text-slate-900 dark:text-white">In Progress</p>
                <p className="text-xs text-slate-600 dark:text-slate-400">Learning</p>
              </div>
              
              <div className="text-center" data-testid="locked-progress">
                <div className="w-12 h-12 bg-slate-200 dark:bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-2">
                  <span className="text-lg font-bold text-slate-500 dark:text-slate-400">
                    {lockedCount}
                  </span>
                </div>
                <p className="text-sm font-medium text-slate-900 dark:text-white">Locked</p>
                <p className="text-xs text-slate-600 dark:text-slate-400">Remaining</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Learning Modules */}
        <div className="grid gap-6">
          {SPECIALIZATIONS.map((specialization) => {
            const status = getSpecializationStatus(specialization);
            const StatusIcon = getStatusIcon(status);
            const isLocked = status === 'locked';

            return (
              <Card
                key={specialization.id}
                className={`${isLocked ? 'bg-slate-50 dark:bg-slate-800/50 opacity-75' : 'bg-white dark:bg-slate-800'} border border-slate-200 dark:border-slate-700`}
                data-testid={`specialization-${specialization.id}`}
              >
                <CardHeader>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        status === 'completed' ? 'bg-green-500' :
                        status === 'in-progress' ? 'bg-blue-500 animate-pulse' :
                        'bg-slate-400'
                      }`}>
                        <StatusIcon className="w-4 h-4 text-white" />
                      </div>
                      <CardTitle className={isLocked ? 'text-slate-600 dark:text-slate-400' : ''}>
                        {specialization.name}
                      </CardTitle>
                    </div>
                    {getStatusBadge(status)}
                  </div>
                </CardHeader>

                <CardContent>
                  <p className={`text-sm mb-4 ${isLocked ? 'text-slate-500 dark:text-slate-400' : 'text-slate-600 dark:text-slate-400'}`}>
                    {specialization.description}
                  </p>

                  {status === 'in-progress' && specialization.learningProgress !== undefined && (
                    <div className="mb-4">
                      <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400 mb-1">
                        <span>Progress</span>
                        <span>{specialization.learningProgress}% Complete</span>
                      </div>
                      <Progress value={specialization.learningProgress} className="h-2" />
                    </div>
                  )}

                  {isLocked && specialization.prerequisite && (
                    <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
                      Complete "{SPECIALIZATIONS.find(s => s.id === specialization.prerequisite)?.name}" to unlock this specialization.
                    </p>
                  )}

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="text-xs text-slate-500 dark:text-slate-400">
                        {status === 'completed' ? 'Income Unlocked:' : 'Will Unlock:'}
                      </span>
                      <span className={`text-sm font-semibold ${
                        status === 'completed' 
                          ? 'text-green-600 dark:text-green-400'
                          : isLocked 
                          ? 'text-slate-500 dark:text-slate-400'
                          : 'text-blue-600 dark:text-blue-400'
                      }`}>
                        +{Math.round((specialization.incomeMultiplier - 1) * 100)}% Income
                      </span>
                    </div>

                    <Button
                      className={`text-sm font-medium py-2 px-4 ${
                        status === 'completed' 
                          ? 'bg-green-500 text-white cursor-default'
                          : status === 'in-progress'
                          ? 'bg-blue-500 hover:bg-blue-600 text-white'
                          : 'bg-slate-400 text-white cursor-not-allowed'
                      }`}
                      disabled={status === 'completed' || isLocked}
                      data-testid={`learn-button-${specialization.id}`}
                    >
                      {status === 'completed' ? (
                        <>
                          <CheckCircle className="w-4 h-4 mr-1" />
                          Completed ✓
                        </>
                      ) : status === 'in-progress' ? (
                        'Continue Learning'
                      ) : (
                        <>
                          <Lock className="w-4 h-4 mr-1" />
                          🔒 Locked
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
