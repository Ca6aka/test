import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Server, Power, PowerOff, Settings, Plus } from 'lucide-react';
import { useGame } from '@/contexts/game-context';
import { useToast } from '@/hooks/use-toast';
import { formatCurrency } from '@/lib/constants';

export function ServersTab() {
  const { gameState, toggleServer } = useGame();
  const { toast } = useToast();

  const handleToggleServer = async (serverId: string) => {
    try {
      await toggleServer(serverId);
      toast({
        title: "Server Status Changed",
        description: "Server power state has been updated",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleGoToStore = () => {
    // This would be handled by the parent component to switch tabs
    // For now, we'll just show a message
    toast({
      title: "Navigate to Server Store",
      description: "Click on the 'Server Store' tab to purchase new servers",
    });
  };

  if (!gameState.user) return null;

  return (
    <div className="p-6">
      <div className="max-w-6xl">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">
            My Server Fleet
          </h2>
          <p className="text-slate-600 dark:text-slate-400">
            Monitor and manage your server infrastructure
          </p>
        </div>

        {/* Server Grid */}
        <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {gameState.servers.map((server) => (
            <Card
              key={server.id}
              className="server-card bg-gradient-to-br from-blue-50/50 to-green-50/50 dark:from-blue-900/20 dark:to-green-900/20 hover:shadow-lg transition-all"
              data-testid={`server-card-${server.id}`}
            >
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className={`w-3 h-3 rounded-full ${
                      server.isOnline ? 'bg-green-500 animate-pulse' : 'bg-red-500'
                    }`} />
                    <CardTitle className="text-base">{server.name}</CardTitle>
                  </div>
                  <Badge variant={server.isOnline ? "default" : "secondary"}>
                    {server.isOnline ? 'Online' : 'Offline'}
                  </Badge>
                </div>
              </CardHeader>

              <CardContent>
                <div className="space-y-3 mb-6">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-600 dark:text-slate-400">Specialization:</span>
                    <span className="font-medium text-slate-900 dark:text-white">
                      {server.specialization || 'None'}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-600 dark:text-slate-400">CPU:</span>
                    <span className="font-medium text-slate-900 dark:text-white">
                      {server.specs.cpu}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-600 dark:text-slate-400">RAM:</span>
                    <span className="font-medium text-slate-900 dark:text-white">
                      {server.specs.ram}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-600 dark:text-slate-400">Storage:</span>
                    <span className="font-medium text-slate-900 dark:text-white">
                      {server.specs.storage}
                    </span>
                  </div>
                  {server.specs.gpu && (
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600 dark:text-slate-400">GPU:</span>
                      <span className="font-medium text-slate-900 dark:text-white">
                        {server.specs.gpu}
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between text-sm font-semibold border-t border-slate-200 dark:border-slate-700 pt-3">
                    <span className="text-slate-600 dark:text-slate-400">Income/min:</span>
                    <span className="text-green-600 dark:text-green-400">
                      {server.isOnline ? formatCurrency(server.incomePerMinute) : '$0.00'}
                    </span>
                  </div>
                </div>

                <div className="flex space-x-2">
                  <Button
                    className={`flex-1 ${server.isOnline 
                      ? 'bg-red-500 hover:bg-red-600' 
                      : 'bg-green-500 hover:bg-green-600'
                    } text-white text-sm font-medium`}
                    onClick={() => handleToggleServer(server.id)}
                    data-testid={`toggle-server-${server.id}`}
                  >
                    {server.isOnline ? (
                      <>
                        <PowerOff className="w-4 h-4 mr-1" />
                        Power Off
                      </>
                    ) : (
                      <>
                        <Power className="w-4 h-4 mr-1" />
                        Power On
                      </>
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    className="flex-1 text-sm font-medium"
                    disabled
                    data-testid={`configure-server-${server.id}`}
                  >
                    <Settings className="w-4 h-4 mr-1" />
                    Configure
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}

          {/* Empty State / Add New Server */}
          <Card className="bg-slate-50 dark:bg-slate-800/50 border-2 border-dashed border-slate-300 dark:border-slate-600 hover:border-slate-400 dark:hover:border-slate-500 transition-colors">
            <CardContent className="p-8 flex flex-col items-center justify-center text-center">
              <Plus className="w-12 h-12 text-slate-400 dark:text-slate-500 mb-4" />
              <h3 className="font-semibold text-slate-900 dark:text-white mb-2">
                Add New Server
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                Purchase servers from the Server Store
              </p>
              <Button
                onClick={handleGoToStore}
                data-testid="go-to-store-button"
              >
                <Server className="w-4 h-4 mr-1" />
                Visit Store
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
