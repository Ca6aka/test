import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Lightbulb, X } from 'lucide-react';
import { useGame } from '@/contexts/game-context';
import { TUTORIAL_UNLOCK_THRESHOLD, formatCurrency } from '@/lib/constants';

export function VirtualAssistant() {
  const { gameState, completeTutorial } = useGame();
  const [isVisible, setIsVisible] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (!gameState.user) return;

    // Show assistant for new users or when they reach the unlock threshold
    if (!gameState.user.tutorialCompleted) {
      if (gameState.user.balance === 0) {
        setMessage(
          `Welcome to ServerSim! I'm here to guide you through your journey to becoming a server management expert.
          
To get started, you'll need to earn your first ${formatCurrency(TUTORIAL_UNLOCK_THRESHOLD)} by completing simple jobs. Once you reach this amount, I'll unlock the Server Store where you can purchase your first server!

Ready to begin your IT empire?`
        );
        setIsVisible(true);
      } else if (gameState.user.balance >= TUTORIAL_UNLOCK_THRESHOLD) {
        setMessage(
          `Congratulations! You've earned ${formatCurrency(gameState.user.balance)}! 🎉

You've unlocked the Server Store! Now you can purchase your first server and start earning passive income. Visit the "Server Store" tab to browse available servers.

Your journey to building an IT empire has just begun!`
        );
        setIsVisible(true);
        
        // Auto-complete tutorial after showing this message
        setTimeout(() => {
          completeTutorial();
        }, 5000);
      }
    }
  }, [gameState.user, completeTutorial]);

  const handleStart = () => {
    setIsVisible(false);
  };

  const handleSkip = () => {
    setIsVisible(false);
    if (gameState.user && !gameState.user.tutorialCompleted) {
      completeTutorial();
    }
  };

  if (!isVisible || !gameState.user) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center z-50" data-testid="virtual-assistant">
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 p-8 max-w-md mx-4 transform scale-100 transition-transform">
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Lightbulb className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">AI Assistant</h3>
        </div>

        <div className="bg-slate-50 dark:bg-slate-700 rounded-xl p-4 mb-6">
          <p className="text-sm text-slate-700 dark:text-slate-300 whitespace-pre-line">
            {message}
          </p>
        </div>

        <div className="flex space-x-3">
          <Button 
            onClick={handleStart}
            className="flex-1 bg-blue-500 hover:bg-blue-600 text-white"
            data-testid="start-tutorial-button"
          >
            {gameState.user.balance >= TUTORIAL_UNLOCK_THRESHOLD ? "Let's Go!" : "Let's Start!"}
          </Button>
          <Button 
            variant="ghost"
            onClick={handleSkip}
            className="px-4 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200"
            data-testid="skip-tutorial-button"
          >
            Skip
          </Button>
        </div>
      </div>
    </div>
  );
}
