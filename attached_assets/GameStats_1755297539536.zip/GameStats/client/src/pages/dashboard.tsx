import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Lock } from 'lucide-react';
import { StatusBar } from '@/components/status-bar';
import { VirtualAssistant } from '@/components/virtual-assistant';
import { TutorialTab } from '@/components/tutorial-tab';
import { ServersTab } from '@/components/servers-tab';
import { HostingTab } from '@/components/hosting-tab';
import { LearningTab } from '@/components/learning-tab';
import { useGame } from '@/contexts/game-context';
import { useLanguage } from '@/contexts/language-context';
import { TUTORIAL_UNLOCK_THRESHOLD, formatCurrency } from '@/lib/constants';

type TabType = 'tutorial' | 'servers' | 'hosting' | 'learning';

export default function DashboardPage() {
  const { gameState } = useGame();
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<TabType>('tutorial');

  const isTabUnlocked = (tab: TabType) => {
    if (tab === 'tutorial') return true;
    return gameState.user && (gameState.user.balance >= TUTORIAL_UNLOCK_THRESHOLD || gameState.user.tutorialCompleted);
  };

  const getTabContent = () => {
    switch (activeTab) {
      case 'tutorial': return <TutorialTab />;
      case 'servers': return <ServersTab />;
      case 'hosting': return <HostingTab />;
      case 'learning': return <LearningTab />;
      default: return <TutorialTab />;
    }
  };

  if (!gameState.user) return null;

  const progressPercentage = Math.min((gameState.user.balance / TUTORIAL_UNLOCK_THRESHOLD) * 100, 100);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <StatusBar />
      
      <div className="flex h-[calc(100vh-80px)]">
        {/* Sidebar Navigation */}
        <nav className="w-64 bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700 p-6">
          <div className="space-y-2">
            {/* Tutorial Tab */}
            <Button
              variant={activeTab === 'tutorial' ? 'default' : 'ghost'}
              className={`w-full justify-start space-x-3 ${
                activeTab === 'tutorial'
                  ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                  : 'text-slate-700 dark:text-slate-300'
              }`}
              onClick={() => setActiveTab('tutorial')}
              data-testid="tab-tutorial"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span>{t('tutorial')}</span>
              {!gameState.user.tutorialCompleted && (
                <span className="ml-auto bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300 text-xs px-2 py-1 rounded-full">
                  Active
                </span>
              )}
            </Button>

            {/* My Servers Tab */}
            <Button
              variant={activeTab === 'servers' ? 'default' : 'ghost'}
              className={`w-full justify-start space-x-3 ${
                activeTab === 'servers'
                  ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                  : isTabUnlocked('servers')
                  ? 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                  : 'text-slate-400 dark:text-slate-500 opacity-50 cursor-not-allowed'
              }`}
              onClick={() => isTabUnlocked('servers') && setActiveTab('servers')}
              disabled={!isTabUnlocked('servers')}
              data-testid="tab-servers"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01" />
              </svg>
              <span>{t('servers')}</span>
              {!isTabUnlocked('servers') && <Lock className="w-4 h-4 ml-auto" />}
            </Button>

            {/* Server Store Tab */}
            <Button
              variant={activeTab === 'hosting' ? 'default' : 'ghost'}
              className={`w-full justify-start space-x-3 ${
                activeTab === 'hosting'
                  ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                  : isTabUnlocked('hosting')
                  ? 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                  : 'text-slate-400 dark:text-slate-500 opacity-50 cursor-not-allowed'
              }`}
              onClick={() => isTabUnlocked('hosting') && setActiveTab('hosting')}
              disabled={!isTabUnlocked('hosting')}
              data-testid="tab-hosting"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4l1-12z" />
              </svg>
              <span>{t('serverStore')}</span>
              {!isTabUnlocked('hosting') && <Lock className="w-4 h-4 ml-auto" />}
            </Button>

            {/* Learning Center Tab */}
            <Button
              variant={activeTab === 'learning' ? 'default' : 'ghost'}
              className={`w-full justify-start space-x-3 ${
                activeTab === 'learning'
                  ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                  : isTabUnlocked('learning')
                  ? 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                  : 'text-slate-400 dark:text-slate-500 opacity-50 cursor-not-allowed'
              }`}
              onClick={() => isTabUnlocked('learning') && setActiveTab('learning')}
              disabled={!isTabUnlocked('learning')}
              data-testid="tab-learning"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
              </svg>
              <span>{t('learning')}</span>
              {!isTabUnlocked('learning') && <Lock className="w-4 h-4 ml-auto" />}
            </Button>
          </div>

          {/* Progress to unlock hosting */}
          {!gameState.user.tutorialCompleted && (
            <div className="mt-8 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
              <h3 className="text-sm font-semibold text-blue-900 dark:text-blue-100 mb-2">
                {t('unlockServerStore')}
              </h3>
              <Progress value={progressPercentage} className="mb-2" />
              <p className="text-xs text-blue-700 dark:text-blue-300">
                {formatCurrency(gameState.user.balance)} / {formatCurrency(TUTORIAL_UNLOCK_THRESHOLD)}
              </p>
            </div>
          )}
        </nav>

        {/* Content Area */}
        <main className="flex-1 overflow-auto">
          {getTabContent()}
        </main>
      </div>

      <VirtualAssistant />
    </div>
  );
}
