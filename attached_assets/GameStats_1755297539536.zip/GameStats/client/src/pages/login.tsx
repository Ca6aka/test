import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Server } from 'lucide-react';
import { useGame } from '@/contexts/game-context';
import { useToast } from '@/hooks/use-toast';

export default function LoginPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [nickname, setNickname] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const { login, register, isLoading } = useGame();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (isLogin) {
        await login(nickname, password);
      } else {
        if (password !== confirmPassword) {
          toast({
            title: "Error",
            description: "Passwords don't match",
            variant: "destructive",
          });
          return;
        }
        await register(nickname, password, confirmPassword);
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-slate-900 dark:to-slate-800">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50/90 to-indigo-100/90 dark:from-slate-900/90 dark:to-slate-800/90" />
      
      <div className="relative z-10 max-w-md w-full mx-4">
        <Card className="shadow-2xl border border-slate-200 dark:border-slate-700">
          <CardHeader className="text-center pb-2">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl mb-4 mx-auto">
              <Server className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-3xl font-bold text-slate-900 dark:text-white">
              ServerSim
            </CardTitle>
            <p className="text-slate-600 dark:text-slate-400 mt-2">
              IT Server Management Simulator
            </p>
          </CardHeader>

          <CardContent className="pt-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="nickname" className="text-slate-700 dark:text-slate-300">
                  Nickname
                </Label>
                <Input
                  id="nickname"
                  type="text"
                  value={nickname}
                  onChange={(e) => setNickname(e.target.value)}
                  placeholder="Enter your nickname"
                  required
                  className="mt-2"
                  data-testid="input-nickname"
                />
              </div>

              <div>
                <Label htmlFor="password" className="text-slate-700 dark:text-slate-300">
                  Password
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  required
                  className="mt-2"
                  data-testid="input-password"
                />
              </div>

              {!isLogin && (
                <div>
                  <Label htmlFor="confirmPassword" className="text-slate-700 dark:text-slate-300">
                    Confirm Password
                  </Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Confirm your password"
                    required
                    className="mt-2"
                    data-testid="input-confirm-password"
                  />
                </div>
              )}

              <div className="flex space-x-4">
                <Button
                  type="submit"
                  className="flex-1 bg-blue-500 hover:bg-blue-600 text-white font-semibold"
                  disabled={isLoading}
                  data-testid={isLogin ? "button-login" : "button-register"}
                >
                  {isLoading ? 'Loading...' : (isLogin ? 'Login' : 'Register')}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={() => setIsLogin(!isLogin)}
                  disabled={isLoading}
                  data-testid="button-toggle-mode"
                >
                  {isLogin ? 'Register' : 'Login'}
                </Button>
              </div>
            </form>

            <div className="mt-6 pt-6 border-t border-slate-200 dark:border-slate-700">
              <p className="text-xs text-slate-500 dark:text-slate-400 text-center">
                Build and manage your server empire • Earn passive income • Master IT specializations
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
