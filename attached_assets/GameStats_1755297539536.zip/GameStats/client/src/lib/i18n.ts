export type Language = 'en' | 'ru' | 'de';

export const languages: Record<Language, string> = {
  en: 'English',
  ru: 'Русский',
  de: 'Deutsch'
};

export const translations = {
  en: {
    // Navigation
    tutorial: 'Start',
    servers: 'Servers',
    learning: 'Learning',
    
    // Auth
    login: 'Login',
    register: 'Register',
    nickname: 'Nickname',
    password: 'Password',
    loginButton: 'Sign In',
    registerButton: 'Create Account',
    logout: 'Logout',
    
    // Tutorial Tab
    tutorialTitle: 'Get Started - Earn Your First $150',
    tutorialDescription: 'Complete simple jobs to unlock the Server Store and begin your IT empire!',
    recentActivities: 'Recent Activities',
    noActivitiesYet: 'No activities yet. Complete your first job to get started!',
    earnedMoney: 'Earned',
    
    // Jobs
    vpnSetup: 'VPN Setup',
    vpnDescription: 'Configure VPN connections for small businesses',
    dogWalking: 'Dog Walking',
    dogWalkingDescription: 'Walk dogs in your neighborhood for extra cash',
    computerSetup: 'Computer Setup',
    computerSetupDescription: 'Set up computers and install software for clients',
    
    // Job Actions
    startJob: 'Start Job',
    onCooldown: 'On Cooldown',
    cooldown: 'Cooldown',
    ready: 'Ready!',
    completed: 'Completed',
    
    // Servers Tab
    serversTitle: 'Server Management',
    serverStore: 'Server Store',
    myServers: 'My Servers',
    unlockServerStore: 'Unlock Server Store',
    unlockDescription: 'Complete tutorial jobs and earn $150 to access the server store',
    currentBalance: 'Current Balance',
    purchaseServer: 'Purchase Server',
    
    // Server Details
    serverName: 'Server Name',
    cpu: 'CPU',
    ram: 'RAM',
    storage: 'Storage',
    gpu: 'GPU',
    price: 'Price',
    incomePerMinute: 'Income/min',
    online: 'Online',
    offline: 'Offline',
    
    // Learning Tab
    learningTitle: 'Learning & Specializations',
    learningDescription: 'Unlock new server types and increase your earning potential',
    availableSpecializations: 'Available Specializations',
    
    // Common
    balance: 'Balance',
    loading: 'Loading...',
    error: 'Error',
    success: 'Success',
    
    // Time formats
    seconds: 'sec',
    minutes: 'min',
    hours: 'hr',
    
    // Theme
    lightMode: 'Light Mode',
    darkMode: 'Dark Mode',
    language: 'Language'
  },
  
  ru: {
    // Navigation
    tutorial: 'Начало',
    servers: 'Серверы',
    learning: 'Изучение',
    
    // Auth
    login: 'Вход',
    register: 'Регистрация',
    nickname: 'Никнейм',
    password: 'Пароль',
    loginButton: 'Войти',
    registerButton: 'Создать аккаунт',
    logout: 'Выйти',
    
    // Tutorial Tab
    tutorialTitle: 'Начало - Заработайте первые $150',
    tutorialDescription: 'Выполняйте простые задания, чтобы разблокировать магазин серверов и начать свою IT-империю!',
    recentActivities: 'Последние действия',
    noActivitiesYet: 'Пока нет действий. Выполните первое задание, чтобы начать!',
    earnedMoney: 'Заработано',
    
    // Jobs
    vpnSetup: 'Настройка VPN',
    vpnDescription: 'Настройка VPN-подключений для малого бизнеса',
    dogWalking: 'Выгул собак',
    dogWalkingDescription: 'Выгуливайте собак в районе для дополнительного заработка',
    computerSetup: 'Настройка компьютеров',
    computerSetupDescription: 'Настройка компьютеров и установка ПО для клиентов',
    
    // Job Actions
    startJob: 'Начать работу',
    onCooldown: 'Восстановление',
    cooldown: 'Восстановление',
    ready: 'Готово!',
    completed: 'Выполнено',
    
    // Servers Tab
    serversTitle: 'Управление серверами',
    serverStore: 'Магазин серверов',
    myServers: 'Мои серверы',
    unlockServerStore: 'Разблокировать магазин',
    unlockDescription: 'Завершите обучающие задания и заработайте $150 для доступа к магазину серверов',
    currentBalance: 'Текущий баланс',
    purchaseServer: 'Купить сервер',
    
    // Server Details
    serverName: 'Название сервера',
    cpu: 'Процессор',
    ram: 'Оперативная память',
    storage: 'Накопитель',
    gpu: 'Видеокарта',
    price: 'Цена',
    incomePerMinute: 'Доход/мин',
    online: 'Онлайн',
    offline: 'Оффлайн',
    
    // Learning Tab
    learningTitle: 'Обучение и специализации',
    learningDescription: 'Разблокируйте новые типы серверов и увеличьте свой потенциал заработка',
    availableSpecializations: 'Доступные специализации',
    
    // Common
    balance: 'Баланс',
    loading: 'Загрузка...',
    error: 'Ошибка',
    success: 'Успех',
    
    // Time formats
    seconds: 'сек',
    minutes: 'мин',
    hours: 'ч',
    
    // Theme
    lightMode: 'Светлая тема',
    darkMode: 'Тёмная тема',
    language: 'Язык'
  },
  
  de: {
    // Navigation
    tutorial: 'Tutorial',
    servers: 'Server',
    learning: 'Lernen',
    
    // Auth
    login: 'Anmelden',
    register: 'Registrieren',
    nickname: 'Benutzername',
    password: 'Passwort',
    loginButton: 'Einloggen',
    registerButton: 'Konto erstellen',
    logout: 'Abmelden',
    
    // Tutorial Tab
    tutorialTitle: 'Erste Schritte - Verdienen Sie Ihre ersten $150',
    tutorialDescription: 'Erledigen Sie einfache Jobs, um den Server-Shop freizuschalten und Ihr IT-Imperium zu beginnen!',
    recentActivities: 'Letzte Aktivitäten',
    noActivitiesYet: 'Noch keine Aktivitäten. Erledigen Sie Ihren ersten Job um zu beginnen!',
    earnedMoney: 'Verdient',
    
    // Jobs
    vpnSetup: 'VPN-Einrichtung',
    vpnDescription: 'VPN-Verbindungen für kleine Unternehmen konfigurieren',
    dogWalking: 'Hundesitting',
    dogWalkingDescription: 'Hunde in Ihrer Nachbarschaft spazieren führen für extra Geld',
    computerSetup: 'Computer-Setup',
    computerSetupDescription: 'Computer einrichten und Software für Kunden installieren',
    
    // Job Actions
    startJob: 'Job starten',
    onCooldown: 'Abklingzeit',
    cooldown: 'Abklingzeit',
    ready: 'Bereit!',
    completed: 'Abgeschlossen',
    
    // Servers Tab
    serversTitle: 'Server-Verwaltung',
    serverStore: 'Server-Shop',
    myServers: 'Meine Server',
    unlockServerStore: 'Server-Shop freischalten',
    unlockDescription: 'Beenden Sie Tutorial-Jobs und verdienen Sie $150 um Zugang zum Server-Shop zu erhalten',
    currentBalance: 'Aktueller Kontostand',
    purchaseServer: 'Server kaufen',
    
    // Server Details
    serverName: 'Server-Name',
    cpu: 'CPU',
    ram: 'RAM',
    storage: 'Speicher',
    gpu: 'GPU',
    price: 'Preis',
    incomePerMinute: 'Einkommen/Min',
    online: 'Online',
    offline: 'Offline',
    
    // Learning Tab
    learningTitle: 'Lernen & Spezialisierungen',
    learningDescription: 'Schalten Sie neue Server-Typen frei und erhöhen Sie Ihr Verdienstpotential',
    availableSpecializations: 'Verfügbare Spezialisierungen',
    
    // Common
    balance: 'Kontostand',
    loading: 'Lädt...',
    error: 'Fehler',
    success: 'Erfolg',
    
    // Time formats
    seconds: 'Sek',
    minutes: 'Min',
    hours: 'Std',
    
    // Theme
    lightMode: 'Heller Modus',
    darkMode: 'Dunkler Modus',
    language: 'Sprache'
  }
};

export const getTranslation = (language: Language, key: keyof typeof translations.en): string => {
  return translations[language][key] || translations.en[key];
};