import { JobType, ServerProduct, Specialization } from "@shared/schema";

export const JOBS: JobType[] = [
  {
    id: "vpn",
    name: "Help Install VPN",
    description: "Assist a client with VPN setup and configuration.",
    reward: 500,
    cooldownSeconds: 30,
    icon: "shield-check"
  },
  {
    id: "dog_walk",
    name: "Walk Someone's Dog",
    description: "Take a neighbor's dog for a refreshing walk.",
    reward: 1000,
    cooldownSeconds: 60,
    icon: "heart"
  },
  {
    id: "computer_setup",
    name: "Setup Computer",
    description: "Help configure and optimize a new computer system.",
    reward: 2000,
    cooldownSeconds: 180,
    icon: "monitor"
  }
];

export const SERVER_PRODUCTS: ServerProduct[] = [
  {
    id: "basic-mail",
    name: "BasicMail Pro",
    category: "entry",
    price: 150,
    specs: {
      cpu: "4 cores @ 2.4GHz",
      ram: "8 GB DDR4",
      storage: "500 GB SSD"
    },
    bestFor: "Mail Service",
    incomePerMinute: 250 // $2.50 in cents
  },
  {
    id: "web-host-elite",
    name: "WebHost Elite",
    category: "professional",
    price: 280,
    specs: {
      cpu: "8 cores @ 3.2GHz",
      ram: "16 GB DDR4",
      storage: "1 TB NVMe SSD"
    },
    bestFor: "Web Hosting",
    incomePerMinute: 420 // $4.20 in cents
  },
  {
    id: "data-vault-max",
    name: "DataVault Max",
    category: "enterprise",
    price: 650,
    specs: {
      cpu: "16 cores @ 3.8GHz",
      ram: "64 GB DDR5",
      storage: "4 TB NVMe RAID"
    },
    bestFor: "Data Storage",
    incomePerMinute: 875 // $8.75 in cents
  },
  {
    id: "ai-processor",
    name: "AI ProcessorPro",
    category: "enterprise",
    price: 800,
    specs: {
      cpu: "24 cores @ 4.0GHz",
      ram: "128 GB DDR5",
      storage: "2 TB NVMe SSD",
      gpu: "RTX 4090"
    },
    bestFor: "AI Processing",
    incomePerMinute: 1200 // $12.00 in cents
  },
  {
    id: "game-server",
    name: "GameMaster Server",
    category: "professional",
    price: 450,
    specs: {
      cpu: "12 cores @ 3.5GHz",
      ram: "32 GB DDR4",
      storage: "2 TB SSD"
    },
    bestFor: "Game Hosting",
    incomePerMinute: 680 // $6.80 in cents
  }
];

export const SPECIALIZATIONS: Specialization[] = [
  {
    id: "mail-service",
    name: "Mail Service",
    description: "Learn the basics of email server management, SMTP configuration, and security protocols.",
    incomeMultiplier: 1.0,
    learningProgress: 100
  },
  {
    id: "web-hosting",
    name: "Web Hosting",
    description: "Master Apache/Nginx configuration, SSL certificates, and performance optimization.",
    incomeMultiplier: 1.2,
    prerequisite: "mail-service",
    learningProgress: 65
  },
  {
    id: "database",
    name: "Database Administration",
    description: "Advanced database management, optimization, and backup strategies.",
    incomeMultiplier: 1.4,
    prerequisite: "web-hosting",
    learningProgress: 0
  },
  {
    id: "ai-processing",
    name: "AI Processing",
    description: "Machine learning model deployment and GPU optimization.",
    incomeMultiplier: 2.0,
    prerequisite: "database",
    learningProgress: 0
  },
  {
    id: "data-storage",
    name: "Data Storage",
    description: "Enterprise storage solutions, RAID configuration, and data redundancy.",
    incomeMultiplier: 1.6,
    prerequisite: "database",
    learningProgress: 0
  },
  {
    id: "game-hosting",
    name: "Game Hosting",
    description: "Game server optimization, anti-cheat systems, and performance monitoring.",
    incomeMultiplier: 1.3,
    prerequisite: "web-hosting",
    learningProgress: 0
  },
  {
    id: "cdn",
    name: "Content Delivery Network",
    description: "Global content distribution and edge server management.",
    incomeMultiplier: 1.7,
    prerequisite: "web-hosting",
    learningProgress: 0
  },
  {
    id: "blockchain",
    name: "Blockchain Hosting",
    description: "Cryptocurrency nodes, smart contracts, and distributed ledger systems.",
    incomeMultiplier: 2.2,
    prerequisite: "ai-processing",
    learningProgress: 0
  },
  {
    id: "iot",
    name: "IoT Management",
    description: "Internet of Things device coordination and data processing.",
    incomeMultiplier: 1.5,
    prerequisite: "data-storage",
    learningProgress: 0
  },
  {
    id: "quantum",
    name: "Quantum Computing",
    description: "Next-generation quantum processor management and optimization.",
    incomeMultiplier: 3.0,
    prerequisite: "blockchain",
    learningProgress: 0
  }
];

export const TUTORIAL_UNLOCK_THRESHOLD = 15000; // $150 in cents

export const formatCurrency = (cents: number): string => {
  return `$${(cents / 100).toFixed(2)}`;
};

export const formatTime = (seconds: number): string => {
  if (seconds <= 0) return "Ready!";
  
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  
  if (minutes > 0) {
    return `${minutes}m ${remainingSeconds}s`;
  } else {
    return `${remainingSeconds}s`;
  }
};
