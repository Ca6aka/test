# ServerSim - IT Server Management Game

## Overview

ServerSim is a full-stack web application that simulates IT server management as a game. Players start by earning money through simple jobs, then purchase and manage servers to build their IT empire. The application features a React frontend with modern UI components, a Node.js/Express backend with session-based authentication, and a PostgreSQL database managed through Drizzle ORM.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The frontend uses React with TypeScript, built on top of Vite for fast development and optimized builds. The UI is constructed using shadcn/ui components based on Radix UI primitives with Tailwind CSS for styling. The application follows a component-based architecture with:

- **State Management**: React Context API for global game state management, combined with TanStack Query for server state synchronization
- **Routing**: Wouter for lightweight client-side routing
- **Theme System**: Custom theme provider supporting light/dark modes with CSS variables
- **Form Handling**: React Hook Form with Zod validation for type-safe form management

The frontend is organized into logical sections:
- `/components`: Reusable UI components including game-specific tabs and controls
- `/pages`: Main application views (login, dashboard, not-found)
- `/hooks`: Custom React hooks for shared logic
- `/contexts`: React Context providers for global state
- `/lib`: Utility functions, constants, and configuration

### Backend Architecture
The backend uses Node.js with Express.js following a REST API pattern. The server architecture includes:

- **Session Management**: Express sessions with in-memory storage for user authentication
- **API Routes**: RESTful endpoints for authentication, game actions, and data persistence
- **Data Storage**: Hybrid approach using both PostgreSQL (via Drizzle ORM) and file-based storage for user data
- **Security**: Bcrypt for password hashing and session-based authentication

The backend structure includes:
- `/server/routes.ts`: API endpoint definitions and request handling
- `/server/storage.ts`: Data access layer with abstraction for different storage methods
- `/server/vite.ts`: Development server integration with Vite

### Data Storage Solutions
The application uses a dual storage approach:

- **PostgreSQL Database**: Primary storage using Drizzle ORM with schemas for users, servers, activities, and job cooldowns
- **File-based Storage**: JSON files in `/users` directory for backup and compatibility, with example data structure provided
- **Session Storage**: In-memory session management for user authentication state

Database schema includes normalized tables for users, servers, activities, and job cooldowns with proper relationships and constraints.

### Authentication and Authorization
The system implements session-based authentication:

- **Registration/Login**: Nickname and password-based authentication with duplicate prevention
- **Password Security**: Bcrypt hashing with salt rounds for secure password storage
- **Session Management**: Express sessions with configurable expiration and security settings
- **Route Protection**: Middleware-based authentication checks for protected endpoints

### Game Logic Architecture
The game features a progressive unlocking system:

- **Tutorial System**: Initial job-based earning phase to unlock main features
- **Server Management**: Purchase, configuration, and income generation from virtual servers
- **Specialization System**: Learning-based unlocking of server specializations
- **Real-time Updates**: Income calculation and server status management

## External Dependencies

### Core Framework Dependencies
- **React 18**: Frontend framework with modern hooks and concurrent features
- **Node.js/Express**: Backend runtime and web framework
- **TypeScript**: Type safety across the entire stack
- **Vite**: Build tool and development server with HMR support

### Database and ORM
- **PostgreSQL**: Primary database (configured via DATABASE_URL environment variable)
- **Drizzle ORM**: Type-safe database toolkit with schema migrations
- **@neondatabase/serverless**: PostgreSQL connection driver optimized for serverless environments

### UI and Styling
- **Tailwind CSS**: Utility-first CSS framework with custom design system
- **Radix UI**: Headless UI component primitives for accessibility and behavior
- **shadcn/ui**: Pre-built component library built on Radix UI and Tailwind
- **Lucide Icons**: Consistent iconography throughout the application

### State Management and Data Fetching
- **TanStack Query**: Server state management with caching, background updates, and optimistic updates
- **React Hook Form**: Form state management with minimal re-renders
- **Zod**: Runtime type validation for forms and API data

### Authentication and Security
- **bcrypt**: Password hashing library for secure authentication
- **express-session**: Session middleware for user state persistence
- **connect-pg-simple**: PostgreSQL session store adapter

### Development and Build Tools
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Tailwind CSS integration
- **tsx**: TypeScript execution for development server

### Additional Utilities
- **date-fns**: Date manipulation library for time-based game mechanics
- **clsx/tailwind-merge**: Conditional CSS class management
- **wouter**: Lightweight routing library for single-page application navigation