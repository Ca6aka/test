import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { loginSchema, registerSchema, insertActivitySchema, insertServerSchema } from "@shared/schema";
import bcrypt from "bcrypt";
import session from "express-session";
import { SPECIALIZATIONS, JOBS, SERVER_PRODUCTS } from "../client/src/lib/constants";

declare module 'express-session' {
  interface SessionData {
    userId?: string;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Session configuration
  app.use(session({
    secret: process.env.SESSION_SECRET || 'your-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false, // Set to true in production with HTTPS
      maxAge: 1000 * 60 * 60 * 24 * 7, // 1 week
    },
  }));

  // Authentication middleware
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  };

  // Register endpoint
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { nickname, password } = registerSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByNickname(nickname);
      if (existingUser) {
        return res.status(400).json({ message: "Nickname already exists" });
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);
      
      // Create user
      const user = await storage.createUser({
        nickname,
        password: hashedPassword,
      });
      
      req.session.userId = user.id;
      
      res.json({
        user: {
          id: user.id,
          nickname: user.nickname,
          balance: user.balance,
          tutorialCompleted: user.tutorialCompleted,
          unlockedSpecializations: user.unlockedSpecializations,
          settings: user.settings,
        }
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Registration failed" });
    }
  });

  // Login endpoint
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { nickname, password } = loginSchema.parse(req.body);
      
      // Try to load user from file first
      let user = await storage.loadUserFromFile(nickname);
      
      if (!user) {
        // If not found in file, check memory
        user = await storage.getUserByNickname(nickname);
      }
      
      if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      req.session.userId = user.id;
      
      res.json({
        user: {
          id: user.id,
          nickname: user.nickname,
          balance: user.balance,
          tutorialCompleted: user.tutorialCompleted,
          unlockedSpecializations: user.unlockedSpecializations,
          settings: user.settings,
        }
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Login failed" });
    }
  });

  // Logout endpoint
  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  // Get current user
  app.get("/api/auth/me", requireAuth, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({
        user: {
          id: user.id,
          nickname: user.nickname,
          balance: user.balance,
          tutorialCompleted: user.tutorialCompleted,
          unlockedSpecializations: user.unlockedSpecializations,
          settings: user.settings,
        }
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Complete job
  app.post("/api/jobs/:jobType/complete", requireAuth, async (req, res) => {
    try {
      const { jobType } = req.params;
      const job = JOBS.find(j => j.id === jobType);
      
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      const userId = req.session.userId!;
      
      // Check cooldown
      const existingCooldown = await storage.getJobCooldown(userId, jobType);
      if (existingCooldown) {
        const timeSinceLastCompleted = Date.now() - existingCooldown.lastCompleted.getTime();
        const cooldownMs = job.cooldownSeconds * 1000;
        
        if (timeSinceLastCompleted < cooldownMs) {
          const remainingMs = cooldownMs - timeSinceLastCompleted;
          return res.status(429).json({ 
            message: "Job is on cooldown",
            remainingSeconds: Math.ceil(remainingMs / 1000)
          });
        }
      }
      
      // Complete job
      const user = await storage.updateUser(userId, {
        balance: (await storage.getUser(userId))!.balance + job.reward
      });
      
      // Set cooldown
      await storage.setJobCooldown({
        userId,
        jobType,
        lastCompleted: new Date(),
      });
      
      // Create activity
      await storage.createActivity({
        userId,
        type: 'job',
        description: `Completed "${job.name}"`,
        amount: job.reward,
      });
      
      res.json({
        user: {
          id: user.id,
          nickname: user.nickname,
          balance: user.balance,
          tutorialCompleted: user.tutorialCompleted,
          unlockedSpecializations: user.unlockedSpecializations,
          settings: user.settings,
        },
        earnedAmount: job.reward
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get job cooldowns
  app.get("/api/jobs/cooldowns", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const cooldowns: Record<string, number> = {};
      
      for (const job of JOBS) {
        const cooldown = await storage.getJobCooldown(userId, job.id);
        if (cooldown) {
          const timeSinceLastCompleted = Date.now() - cooldown.lastCompleted.getTime();
          const cooldownMs = job.cooldownSeconds * 1000;
          const remainingMs = Math.max(0, cooldownMs - timeSinceLastCompleted);
          cooldowns[job.id] = Math.ceil(remainingMs / 1000);
        } else {
          cooldowns[job.id] = 0;
        }
      }
      
      res.json({ cooldowns });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get servers
  app.get("/api/servers", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const servers = await storage.getServersByUserId(userId);
      res.json({ servers });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Purchase server
  app.post("/api/servers/purchase", requireAuth, async (req, res) => {
    try {
      const { productId } = req.body;
      const userId = req.session.userId!;
      
      const product = SERVER_PRODUCTS.find(p => p.id === productId);
      if (!product) {
        return res.status(404).json({ message: "Server product not found" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || user.balance < product.price) {
        return res.status(400).json({ message: "Insufficient funds" });
      }
      
      // Create server
      const server = await storage.createServer({
        userId,
        name: `${product.name}-${Date.now().toString().slice(-4)}`,
        isOnline: true,
        specialization: product.bestFor,
        specs: product.specs,
        incomePerMinute: product.incomePerMinute,
        purchasePrice: product.price,
      });
      
      // Update user balance
      const updatedUser = await storage.updateUser(userId, {
        balance: user.balance - product.price
      });
      
      // Create activity
      await storage.createActivity({
        userId,
        type: 'server_purchase',
        description: `Purchased ${product.name}`,
        amount: -product.price,
      });
      
      res.json({
        server,
        user: {
          id: updatedUser.id,
          nickname: updatedUser.nickname,
          balance: updatedUser.balance,
          tutorialCompleted: updatedUser.tutorialCompleted,
          unlockedSpecializations: updatedUser.unlockedSpecializations,
          settings: updatedUser.settings,
        }
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Toggle server power
  app.post("/api/servers/:serverId/toggle", requireAuth, async (req, res) => {
    try {
      const { serverId } = req.params;
      const userId = req.session.userId!;
      
      // Verify server belongs to user
      const servers = await storage.getServersByUserId(userId);
      const server = servers.find(s => s.id === serverId);
      
      if (!server) {
        return res.status(404).json({ message: "Server not found" });
      }
      
      const updatedServer = await storage.updateServer(serverId, {
        isOnline: !server.isOnline
      });
      
      res.json({ server: updatedServer });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get activities
  app.get("/api/activities", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const activities = await storage.getActivitiesByUserId(userId, 20);
      res.json({ activities });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Update income (called periodically by client)
  app.post("/api/income/update", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const servers = await storage.getServersByUserId(userId);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      let totalIncome = 0;
      const now = new Date();
      
      for (const server of servers) {
        if (server.isOnline && server.incomePerMinute > 0) {
          const timeDiff = now.getTime() - server.lastIncomeUpdate.getTime();
          const minutesPassed = timeDiff / (1000 * 60);
          const income = Math.floor(server.incomePerMinute * minutesPassed);
          
          if (income > 0) {
            totalIncome += income;
            
            // Update server's last income update time
            await storage.updateServer(server.id, {
              lastIncomeUpdate: now
            });
          }
        }
      }
      
      if (totalIncome > 0) {
        const updatedUser = await storage.updateUser(userId, {
          balance: user.balance + totalIncome
        });
        
        // Create activity for income
        await storage.createActivity({
          userId,
          type: 'server_income',
          description: `Server income earned`,
          amount: totalIncome,
        });
        
        res.json({
          incomeEarned: totalIncome,
          user: {
            id: updatedUser.id,
            nickname: updatedUser.nickname,
            balance: updatedUser.balance,
            tutorialCompleted: updatedUser.tutorialCompleted,
            unlockedSpecializations: updatedUser.unlockedSpecializations,
            settings: updatedUser.settings,
          }
        });
      } else {
        res.json({
          incomeEarned: 0,
          user: {
            id: user.id,
            nickname: user.nickname,
            balance: user.balance,
            tutorialCompleted: user.tutorialCompleted,
            unlockedSpecializations: user.unlockedSpecializations,
            settings: user.settings,
          }
        });
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Complete tutorial
  app.post("/api/tutorial/complete", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const user = await storage.updateUser(userId, {
        tutorialCompleted: true
      });
      
      res.json({
        user: {
          id: user.id,
          nickname: user.nickname,
          balance: user.balance,
          tutorialCompleted: user.tutorialCompleted,
          unlockedSpecializations: user.unlockedSpecializations,
          settings: user.settings,
        }
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
