import { type User, type InsertUser, type Server, type InsertServer, type Activity, type InsertActivity, type JobCooldown, type InsertJobCooldown } from "@shared/schema";
import { randomUUID } from "crypto";
import fs from "fs/promises";
import path from "path";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByNickname(nickname: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<Omit<User, 'id' | 'createdAt'>>): Promise<User>;

  // Server operations
  getServersByUserId(userId: string): Promise<Server[]>;
  createServer(server: InsertServer): Promise<Server>;
  updateServer(id: string, updates: Partial<Omit<Server, 'id' | 'userId' | 'createdAt'>>): Promise<Server>;
  deleteServer(id: string): Promise<void>;

  // Activity operations
  getActivitiesByUserId(userId: string, limit?: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;

  // Job cooldown operations
  getJobCooldown(userId: string, jobType: string): Promise<JobCooldown | undefined>;
  setJobCooldown(cooldown: InsertJobCooldown): Promise<JobCooldown>;

  // File operations
  saveUserToFile(user: User): Promise<void>;
  loadUserFromFile(nickname: string): Promise<User | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private servers: Map<string, Server> = new Map();
  private activities: Map<string, Activity> = new Map();
  private jobCooldowns: Map<string, JobCooldown> = new Map();

  constructor() {
    this.initializeStorage();
  }

  private async initializeStorage() {
    // Ensure users directory exists
    try {
      await fs.mkdir('users', { recursive: true });
    } catch (error) {
      console.log('Users directory already exists or could not be created');
    }
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByNickname(nickname: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.nickname === nickname,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      balance: 0,
      tutorialCompleted: false,
      unlockedSpecializations: [],
      settings: { theme: 'light', notifications: true },
      createdAt: new Date(),
    };
    this.users.set(id, user);
    await this.saveUserToFile(user);
    return user;
  }

  async updateUser(id: string, updates: Partial<Omit<User, 'id' | 'createdAt'>>): Promise<User> {
    const existingUser = this.users.get(id);
    if (!existingUser) {
      throw new Error('User not found');
    }
    
    const updatedUser: User = { ...existingUser, ...updates };
    this.users.set(id, updatedUser);
    await this.saveUserToFile(updatedUser);
    return updatedUser;
  }

  async getServersByUserId(userId: string): Promise<Server[]> {
    return Array.from(this.servers.values()).filter(
      (server) => server.userId === userId,
    );
  }

  async createServer(insertServer: InsertServer): Promise<Server> {
    const id = randomUUID();
    const server: Server = {
      ...insertServer,
      id,
      lastIncomeUpdate: new Date(),
      createdAt: new Date(),
    };
    this.servers.set(id, server);
    return server;
  }

  async updateServer(id: string, updates: Partial<Omit<Server, 'id' | 'userId' | 'createdAt'>>): Promise<Server> {
    const existingServer = this.servers.get(id);
    if (!existingServer) {
      throw new Error('Server not found');
    }
    
    const updatedServer: Server = { ...existingServer, ...updates };
    this.servers.set(id, updatedServer);
    return updatedServer;
  }

  async deleteServer(id: string): Promise<void> {
    this.servers.delete(id);
  }

  async getActivitiesByUserId(userId: string, limit = 50): Promise<Activity[]> {
    const userActivities = Array.from(this.activities.values())
      .filter((activity) => activity.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
    
    return userActivities;
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = randomUUID();
    const activity: Activity = {
      ...insertActivity,
      id,
      createdAt: new Date(),
    };
    this.activities.set(id, activity);
    return activity;
  }

  async getJobCooldown(userId: string, jobType: string): Promise<JobCooldown | undefined> {
    return Array.from(this.jobCooldowns.values()).find(
      (cooldown) => cooldown.userId === userId && cooldown.jobType === jobType,
    );
  }

  async setJobCooldown(insertCooldown: InsertJobCooldown): Promise<JobCooldown> {
    // Find and update existing cooldown or create new one
    const existing = Array.from(this.jobCooldowns.entries()).find(
      ([_, cooldown]) => cooldown.userId === insertCooldown.userId && cooldown.jobType === insertCooldown.jobType
    );
    
    if (existing) {
      // Update existing cooldown
      const [existingId, existingCooldown] = existing;
      const updatedCooldown: JobCooldown = {
        ...existingCooldown,
        lastCompleted: insertCooldown.lastCompleted,
      };
      this.jobCooldowns.set(existingId, updatedCooldown);
      return updatedCooldown;
    } else {
      // Create new cooldown
      const id = randomUUID();
      const cooldown: JobCooldown = {
        ...insertCooldown,
        id,
      };
      this.jobCooldowns.set(id, cooldown);
      return cooldown;
    }
  }

  async saveUserToFile(user: User): Promise<void> {
    const userServers = await this.getServersByUserId(user.id);
    const userActivities = await this.getActivitiesByUserId(user.id);
    
    const userData = {
      ...user,
      servers: userServers,
      activities: userActivities,
    };

    const filePath = path.join('users', `${user.nickname}.json`);
    await fs.writeFile(filePath, JSON.stringify(userData, null, 2));
  }

  async loadUserFromFile(nickname: string): Promise<User | undefined> {
    try {
      const filePath = path.join('users', `${nickname}.json`);
      const fileContent = await fs.readFile(filePath, 'utf-8');
      const userData = JSON.parse(fileContent);
      
      // Restore user to memory
      const user: User = {
        id: userData.id,
        nickname: userData.nickname,
        password: userData.password,
        balance: userData.balance || 0,
        tutorialCompleted: userData.tutorialCompleted || false,
        unlockedSpecializations: userData.unlockedSpecializations || [],
        settings: userData.settings || { theme: 'light', notifications: true },
        createdAt: new Date(userData.createdAt),
      };
      
      this.users.set(user.id, user);
      
      // Restore servers
      if (userData.servers) {
        userData.servers.forEach((serverData: any) => {
          const server: Server = {
            ...serverData,
            createdAt: new Date(serverData.createdAt),
            lastIncomeUpdate: new Date(serverData.lastIncomeUpdate),
          };
          this.servers.set(server.id, server);
        });
      }
      
      // Restore activities
      if (userData.activities) {
        userData.activities.forEach((activityData: any) => {
          const activity: Activity = {
            ...activityData,
            createdAt: new Date(activityData.createdAt),
          };
          this.activities.set(activity.id, activity);
        });
      }
      
      return user;
    } catch (error) {
      return undefined;
    }
  }
}

export const storage = new MemStorage();
