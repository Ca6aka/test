import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nickname: text("nickname").notNull().unique(),
  password: text("password").notNull(),
  balance: integer("balance").notNull().default(0),
  tutorialCompleted: boolean("tutorial_completed").notNull().default(false),
  unlockedSpecializations: jsonb("unlocked_specializations").$type<string[]>().notNull().default([]),
  settings: jsonb("settings").$type<{
    theme: 'light' | 'dark';
    notifications: boolean;
  }>().notNull().default({ theme: 'light', notifications: true }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const servers = pgTable("servers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  isOnline: boolean("is_online").notNull().default(true),
  specialization: text("specialization"),
  specs: jsonb("specs").$type<{
    cpu: string;
    ram: string;
    storage: string;
    gpu?: string;
  }>().notNull(),
  incomePerMinute: integer("income_per_minute").notNull().default(0),
  lastIncomeUpdate: timestamp("last_income_update").notNull().defaultNow(),
  purchasePrice: integer("purchase_price").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const activities = pgTable("activities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  type: text("type").notNull(), // 'job', 'server_purchase', 'server_income', etc.
  description: text("description").notNull(),
  amount: integer("amount").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const jobCooldowns = pgTable("job_cooldowns", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  jobType: text("job_type").notNull(), // 'vpn', 'dog_walk', 'computer_setup'
  lastCompleted: timestamp("last_completed").notNull().defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  nickname: true,
  password: true,
});

export const insertServerSchema = createInsertSchema(servers).omit({
  id: true,
  createdAt: true,
  lastIncomeUpdate: true,
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  createdAt: true,
});

export const insertJobCooldownSchema = createInsertSchema(jobCooldowns).omit({
  id: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertServer = z.infer<typeof insertServerSchema>;
export type Server = typeof servers.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;
export type InsertJobCooldown = z.infer<typeof insertJobCooldownSchema>;
export type JobCooldown = typeof jobCooldowns.$inferSelect;

// Game-specific types
export interface ServerProduct {
  id: string;
  name: string;
  category: 'entry' | 'professional' | 'enterprise';
  price: number;
  specs: {
    cpu: string;
    ram: string;
    storage: string;
    gpu?: string;
  };
  bestFor: string;
  incomePerMinute: number;
}

export interface JobType {
  id: string;
  name: string;
  description: string;
  reward: number;
  cooldownSeconds: number;
  icon: string;
}

export interface Specialization {
  id: string;
  name: string;
  description: string;
  incomeMultiplier: number;
  prerequisite?: string;
  learningProgress?: number;
}

export interface GameState {
  user: User | null;
  servers: Server[];
  activities: Activity[];
  jobCooldowns: Record<string, number>; // jobType -> remainingSeconds
  totalIncomePerMinute: number;
  unlockedTabs: string[];
}

// Login/Register schemas
export const loginSchema = z.object({
  nickname: z.string().min(3, "Nickname must be at least 3 characters").max(20, "Nickname must be at most 20 characters"),
  password: z.string().min(4, "Password must be at least 4 characters"),
});

export const registerSchema = loginSchema.extend({
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export type LoginRequest = z.infer<typeof loginSchema>;
export type RegisterRequest = z.infer<typeof registerSchema>;
